
#include <iostream>  // Provides cout, cin
#include <cstdlib>   // Provides EXIT_SUCCESS

using namespace std;

int main( )
{
	unsigned int m = 26;
		
	while (m > 0)
		{
		m--;
		cout << m << endl;
		}
    return EXIT_SUCCESS;

}

